package com.example.ecosync.Controller;

import com.example.ecosync.Service.LoggerService;
import com.example.ecosync.Service.LogType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/logger")
public class LoggerController {

    @Autowired
    private LoggerService loggerService;

    @PostMapping("/writelog")
    public String WriteLog(@RequestBody LogRequest logRequest) {
        // Call the LoggerService to write the log
        boolean success = loggerService.WriteLog(logRequest.getType(), logRequest.getLogMessage());

        // Return success or error message based on the result
        if (success) {
            return "Log entry created successfully";
        } else {
            return "Failed to create log entry";
        }
    }
}
