package com.example.ecosync.Service;

public interface LoggerService {
    boolean WriteLog(LogType type, String logMessage);
}
