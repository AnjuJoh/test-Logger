package com.example.ecosync.Service.Impl;

import com.example.ecosync.Service.LoggerService;
import com.example.ecosync.Service.LogType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class LoggerServiceImpl implements LoggerService {

    private static final Logger logger = LoggerFactory.getLogger(LoggerServiceImpl.class);

    @Override
    public boolean WriteLog(LogType type, String logMessage) {
        // Check if log type is valid
        if (type == null) {
            logger.error("Invalid log type provided");
            return false; // Failed to create log entry
        }

        // Log the message based on the type
        switch (type) {
            case INFO:
                logger.info(logMessage);
                break;
            case ERROR:
                logger.error(logMessage);
                break;
            default:
                logger.info(logMessage);
                break;
        }

        return true; // Log entry created successfully
    }
}
