package com.example.ecosync.Service;

public enum LogType {
    INFO,
    ERROR
}
