package com.example.ecosync;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.example.ecosync")
public class EcosyncApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcosyncApplication.class, args);
	}

}
