package com.example.ecosync.Controller;

import com.example.ecosync.Service.LogType;

public class LogRequest {
    private LogType type;
    private String logMessage;

    // Getters and setters
    public LogType getType() {
        return type;
    }

    public void setType(LogType type) {
        this.type = type;
    }

    public String getLogMessage() {
        return logMessage;
    }

    public void setLogMessage(String logMessage) {
        this.logMessage = logMessage;
    }
}
