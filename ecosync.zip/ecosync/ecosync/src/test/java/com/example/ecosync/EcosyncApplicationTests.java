package com.example.ecosync;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcosyncApplicationTests {

	@Test
	void contextLoads() {
	}

}
